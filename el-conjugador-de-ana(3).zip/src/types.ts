export interface Question {
    verb: string;
    tense: string;
    pronoun: string;
    answer: string;
    userAnswer?: string;
}
  
export interface QuizState {
    questions: Question[];
    currentQuestionIndex: number;
    score: number;
    currentStreak: number;
    mistakes: Question[];
    isMistakePractice: boolean;
}

export interface Level {
    name: string;
    tenses: string[];
    verbs?: string[];
    questions?: number;
}
  
export interface VerbConjugations {
    [pronoun: string]: string;
}
  
export interface VerbTenses {
    [tense: string]: VerbConjugations;
}
  
export interface Verb {
    type: string;
    tenses: VerbTenses;
}
  
export interface VerbData {
    [verb: string]: Verb;
}
