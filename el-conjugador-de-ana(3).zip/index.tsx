import { verbData, pronounsOrder, levels, commonIrregularVerbs } from './src/data';
import type { QuizState, Question } from './src/types';

class ConjugadorApp {
    // --- STATE ---
    private quizState: QuizState = { questions: [], currentQuestionIndex: 0, score: 0, currentStreak: 0, mistakes: [], isMistakePractice: false };
    private currentLevelIndex: number = 0;
    private gameMode: 'free' | 'progression' = 'free';
    private highestLevelUnlocked: number = 0;
    
    // --- DOM CACHE ---
    private elements: { [key: string]: HTMLElement | null } = {};
    private screenIds = ['welcome-container', 'mode-selection-container', 'level-selection-container', 'exercise-container', 'results-container', 'theory-container'];

    constructor() {
        // The `DOMContentLoaded` event is more reliable than `window.onload`.
        document.addEventListener('DOMContentLoaded', () => {
            this.cacheDOMElements();
            this.setupEventListeners();
            this.showScreen('welcome-container');
        });
    }

    private getEl<T extends HTMLElement>(id: string): T {
        const el = this.elements[id];
        if (!el) {
            throw new Error(`Element with ID '${id}' not found.`);
        }
        return el as T;
    }

    private cacheDOMElements(): void {
        const allIds = [
            ...this.screenIds, 'main-container', 'confetti-canvas', 'level-map', 'theory-tabs-container', 'theory-content-container',
            'level-display', 'score-display', 'streak-display', 'progress-text', 'progress-bar', 'pronoun', 'verb', 'tense',
            'answer-input', 'accent-buttons', 'feedback', 'check-btn', 'next-btn', 'results-title', 'results-subtitle',
            'final-score', 'results-details-container', 'results-details', 'practice-mistakes-btn', 'repeat-level-btn',
            'go-to-theory-btn', 'next-level-btn', 'back-to-map-btn'
        ];
        allIds.forEach(id => {
            this.elements[id] = document.getElementById(id);
        });
    }

    private setupEventListeners(): void {
        this.getEl('main-container').addEventListener('click', this.handleMainClick);

        const answerInput = this.getEl<HTMLInputElement>('answer-input');
        answerInput.addEventListener('keydown', (e: KeyboardEvent) => {
            if (e.key !== 'Enter') return;
            e.preventDefault();
            const checkBtn = this.getEl('check-btn');
            const nextBtn = this.getEl('next-btn');
            if (checkBtn && !checkBtn.classList.contains('hidden')) { 
                this.checkAnswer(); 
            } else if (nextBtn && !nextBtn.classList.contains('hidden')) { 
                this.nextQuestion(); 
            }
        });
    }

    // --- MAIN EVENT HANDLER (DELEGATION) ---
    private handleMainClick = (e: MouseEvent): void => {
        const target = (e.target as HTMLElement).closest('button');
        if (!target) return;

        const id = target.id;

        switch(id) {
            case 'start-game-btn': this.showScreen('mode-selection-container'); break;
            case 'show-theory-btn': this.generateTheoryTabs(); this.showScreen('theory-container'); break;
            case 'mode-free-btn': this.gameMode = 'free'; this.showLevelMap(); break;
            case 'mode-progression-btn': this.gameMode = 'progression'; this.showLevelMap(); break;
            case 'back-to-welcome-from-mode-btn': this.showScreen('welcome-container'); break;
            case 'back-to-mode-btn': this.showScreen('mode-selection-container'); break;
            case 'back-to-welcome-from-theory-btn': this.showScreen('welcome-container'); break;
            case 'home-btn-exercise': this.showLevelMap(); break;
            case 'back-to-levels-from-game-btn': this.showLevelMap(); break;
            case 'check-btn': this.checkAnswer(); break;
            case 'next-btn': this.nextQuestion(); break;
            case 'practice-mistakes-btn': 
                const mistakeQuestions = this.quizState.mistakes.map(m => ({ verb: m.verb, tense: m.tense, pronoun: m.pronoun, answer: m.answer }));
                this.startCustomQuiz(mistakeQuestions, '🧠 Practicando Errores');
                break;
            case 'repeat-level-btn': this.startQuiz(this.currentLevelIndex); break;
            case 'go-to-theory-btn': this.generateTheoryTabs(); this.showScreen('theory-container'); break;
            case 'next-level-btn':
                if (this.currentLevelIndex < levels.length - 1) {
                    this.startQuiz(this.currentLevelIndex + 1);
                } else { this.showLevelMap(); }
                break;
            case 'back-to-map-btn': this.showLevelMap(); break;
        }

        if (target.matches('.level-btn') && target.dataset.levelIndex && !target.disabled) {
            this.startQuiz(parseInt(target.dataset.levelIndex, 10));
        }
        
        if (target.matches('.accent-btn') && target.dataset.char) {
            const char = target.dataset.char;
            const input = this.getEl<HTMLInputElement>('answer-input');
            const start = input.selectionStart ?? input.value.length;
            const end = input.selectionEnd ?? input.value.length;
            input.value = input.value.substring(0, start) + char + input.value.substring(end);
            input.focus();
            input.selectionStart = input.selectionEnd = start + 1;
        }
    }

    // --- SCREEN & UI MANAGEMENT ---
    private showScreen(screenId: string): void {
        this.screenIds.forEach(id => this.getEl(id).classList.add('hidden'));
        this.getEl(screenId).classList.remove('hidden');
    }

    private showLevelMap(): void {
        const levelMap = this.getEl('level-map');
        levelMap.innerHTML = '';
        levels.forEach((level, index) => {
            const isFinalBoss = level.name.includes("👹");
            const btn = document.createElement('button');
            btn.className = `level-btn ${isFinalBoss ? 'final-boss-btn col-span-2 md:col-span-4' : ''}`;
            btn.dataset.levelIndex = String(index);
            
            const levelTenses = level.tenses.map(t => t.replace(' Simple', '').replace(' Compuesto',' P.P.C.').replace(' de Subjuntivo', ' Subj.'));
            
            let lockIcon = '';
            if (this.gameMode === 'progression' && index > this.highestLevelUnlocked) {
                btn.disabled = true;
                lockIcon = '<span>&#128274;</span>'; // Lock emoji
            }

            btn.innerHTML = `
                <span class="level-name">${level.name} ${lockIcon}</span>
                <small class="level-details">${isFinalBoss ? "¡Todos los tiempos!" : levelTenses.join(', ')}</small>
                ${level.questions ? `<small class="level-details">${level.questions} preguntas</small>` : ''}
            `;
            levelMap.appendChild(btn);
        });
        this.showScreen('level-selection-container');
    }

    private generateTheoryTabs(): void {
        const tabsContainer = this.getEl('theory-tabs-container');
        const contentContainer = this.getEl('theory-content-container');
        
        if (tabsContainer.innerHTML !== '') return; // Already generated

        const verbGroups = { 'regular-ar': "Regulares -ar", 'regular-er': "Regulares -er", 'regular-ir': "Regulares -ir", 'irregular': "Irregulares" };
        const displayTenses = Object.keys(verbData.ser.tenses);
        
        const tabButtonsWrapper = document.createElement('div');
        tabButtonsWrapper.className = 'theory-tabs';
        tabsContainer.appendChild(tabButtonsWrapper);

        Object.entries(verbGroups).forEach(([groupKey, groupName], index) => {
            const button = document.createElement('button');
            button.className = 'tab-btn';
            button.textContent = groupName;
            button.dataset.tab = groupKey;
            tabButtonsWrapper.appendChild(button);

            const content = document.createElement('div');
            content.id = `content-${groupKey}`;
            content.className = 'tab-content';
            contentContainer.appendChild(content);

            if (index === 0) {
                button.classList.add('active');
                content.classList.add('active');
            }

            const verbsInGroup = Object.entries(verbData).filter(([_, data]) => data.type === groupKey);
            if (verbsInGroup.length > 0) {
                verbsInGroup.sort(([verbA], [verbB]) => verbA.localeCompare(verbB)).forEach(([verb, data]) => {
                    const groupDiv = document.createElement('div');
                    groupDiv.className = 'theory-verb-group';
                    groupDiv.innerHTML = `<h4>${verb.charAt(0).toUpperCase() + verb.slice(1)}</h4>`;
                    
                    const table = document.createElement('table');
                    table.className = 'theory-table';
                    table.innerHTML = `<thead><tr><th>Tiempo</th><th>Pronombre</th><th>Forma</th></tr></thead>`;
                    const tbody = table.createTBody();

                    displayTenses.forEach(tense => {
                        if (data.tenses[tense]) {
                            const sortedPronouns = Object.keys(data.tenses[tense]).sort((a, b) => pronounsOrder.indexOf(a) - pronounsOrder.indexOf(b));
                            sortedPronouns.forEach((pronoun, pIndex) => {
                                const row = tbody.insertRow();
                                if (pIndex === 0) {
                                    const tenseCell = row.insertCell();
                                    tenseCell.rowSpan = sortedPronouns.length;
                                    tenseCell.textContent = tense;
                                    tenseCell.className = 'tense-cell';
                                }
                                row.insertCell().textContent = pronoun.replace('(que) ', '');
                                row.insertCell().textContent = data.tenses[tense][pronoun];
                            });
                        }
                    });
                    groupDiv.appendChild(table);
                    content.appendChild(groupDiv);
                });
            }
        });
        
        tabsContainer.querySelectorAll('.tab-btn').forEach(button => {
            button.addEventListener('click', () => {
                tabsContainer.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                contentContainer.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
                button.classList.add('active');
                this.getEl(`content-${(button as HTMLElement).dataset.tab}`).classList.add('active');
            });
        });
    }

    private triggerConfetti(): void {
        const confettiCanvas = this.getEl('confetti-canvas');
        for (let i = 0; i < 50; i++) {
            const piece = document.createElement('div');
            piece.style.position = 'absolute';
            const startX = Math.random() * window.innerWidth;
            const startY = -20;
            const endX = startX + (Math.random() - 0.5) * 400;
            const endY = window.innerHeight + 20;
            piece.style.left = `${startX}px`; piece.style.top = `${startY}px`;
            const colors = [getComputedStyle(document.documentElement).getPropertyValue('--accent').trim(), getComputedStyle(document.documentElement).getPropertyValue('--correct').trim(), '#4299e1', '#FBBF24'];
            piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            const size = Math.random() * 8 + 6;
            piece.style.width = `${size}px`; piece.style.height = `${size}px`;
            piece.style.opacity = '0';
            if (Math.random() > 0.5) piece.style.borderRadius = '50%';
            confettiCanvas.appendChild(piece);
            piece.animate([
                { transform: `translate(0, 0) rotate(0deg)`, opacity: 1 },
                { transform: `translate(${endX - startX}px, ${endY - startY}px) rotate(${Math.random() * 720}deg)`, opacity: 0 }
            ], { duration: Math.random() * 2000 + 3000, easing: 'ease-out', delay: Math.random() * 200 }).onfinish = () => piece.remove();
        }
    }
    
    private updateStreakDisplay(): void {
        this.getEl('streak-display').textContent = `🔥 Racha: ${this.quizState.currentStreak}`;
    }

    // --- QUIZ LOGIC ---
    private startCustomQuiz(questions: Question[], title: string): void {
        this.quizState = { questions, currentQuestionIndex: 0, score: 0, currentStreak: 0, mistakes: [], isMistakePractice: true };
        this.showScreen('exercise-container');
        this.getEl('level-display').textContent = title;
        this.updateStreakDisplay();
        this.displayQuestion();
    }
    
    private startQuiz(levelIndex: number): void {
        this.currentLevelIndex = levelIndex;
        const level = levels[levelIndex];
        const numQuestions = level.questions || 10;
        let questionPool: Question[] = [];
        const verbsForLevel = level.verbs || Object.keys(verbData);

        level.tenses.forEach(tense => {
            verbsForLevel.forEach(verb => {
                const tenseForms = verbData[verb]?.tenses[tense];
                if (tenseForms) {
                    Object.entries(tenseForms).forEach(([pronoun, answer]) => {
                        questionPool.push({ verb, tense, pronoun, answer });
                    });
                }
            });
        });

        if (questionPool.length === 0) {
             alert("⚠️ Error: Imposible generar preguntas para este nivel.");
             this.showLevelMap();
             return;
        }

        questionPool.sort(() => 0.5 - Math.random());
        this.quizState = { questions: questionPool.slice(0, numQuestions), currentQuestionIndex: 0, score: 0, currentStreak: 0, mistakes: [], isMistakePractice: false };
        this.showScreen('exercise-container');
        this.getEl('level-display').textContent = level.name;
        this.updateStreakDisplay();
        this.displayQuestion();
    }

    private displayQuestion(): void {
        if (this.quizState.currentQuestionIndex >= this.quizState.questions.length) {
            this.showResults();
            return;
        }
        const q = this.quizState.questions[this.quizState.currentQuestionIndex];
        this.getEl('verb').textContent = q.verb;
        this.getEl('tense').textContent = q.tense;
        this.getEl('pronoun').textContent = q.pronoun.replace('(que) ', '');
        const answerInput = this.getEl<HTMLInputElement>('answer-input');
        answerInput.value = '';
        answerInput.disabled = false;
        answerInput.className = 'input-field text-center text-xl';
        this.getEl('feedback').innerHTML = '';
        this.getEl('check-btn').classList.remove('hidden');
        this.getEl('next-btn').classList.add('hidden');
        answerInput.focus();
        this.getEl('progress-text').textContent = `Pregunta ${this.quizState.currentQuestionIndex + 1} / ${this.quizState.questions.length}`;
        this.getEl('score-display').textContent = `Puntos: ${this.quizState.score}`;
        this.getEl('progress-bar').style.width = `${((this.quizState.currentQuestionIndex) / this.quizState.questions.length) * 100}%`;
        this.updateStreakDisplay();
    }

    private checkAnswer(): void {
        const answerInput = this.getEl<HTMLInputElement>('answer-input');
        if (answerInput.disabled) return;
        const q = this.quizState.questions[this.quizState.currentQuestionIndex];
        const userAnswer = answerInput.value.trim().toLowerCase();
        const correctAnswers = q.answer.toLowerCase().split(/ ou | \/ /).map(a => a.trim());
        const feedbackEl = this.getEl('feedback');
        
        if (correctAnswers.includes(userAnswer)) {
            feedbackEl.textContent = "✅ ¡Correcto!";
            feedbackEl.className = 'correct my-4 text-lg font-semibold min-h-[28px]';
            answerInput.classList.add('correct-input');
            this.quizState.score++;
            this.quizState.currentStreak++;
            if (this.quizState.currentStreak > 0 && this.quizState.currentStreak % 5 === 0) {
                this.triggerConfetti();
            }
        } else {
            feedbackEl.innerHTML = `❌ Incorrecto. La respuesta correcta es: <span class="font-bold">${q.answer}</span>`;
            feedbackEl.className = 'incorrect my-4 text-lg font-semibold min-h-[28px]';
            answerInput.classList.add('incorrect-input');
            this.quizState.currentStreak = 0;
            this.quizState.mistakes.push({ ...q, userAnswer: answerInput.value.trim() });
        }
        answerInput.disabled = true;
        this.getEl('check-btn').classList.add('hidden');
        this.getEl('next-btn').classList.remove('hidden');
        this.getEl<HTMLButtonElement>('next-btn').focus();
        this.getEl('score-display').textContent = `Puntos: ${this.quizState.score}`;
        this.updateStreakDisplay();
    }

    private nextQuestion(): void {
        this.quizState.currentQuestionIndex++;
        this.displayQuestion();
    }
    
    private displayResultsDetails(): void {
        const detailsContainer = this.getEl('results-details');
        const containerWrapper = this.getEl('results-details-container');
        const practiceBtn = this.getEl('practice-mistakes-btn');
        
        detailsContainer.innerHTML = '';
        if (this.quizState.mistakes.length > 0) {
            this.quizState.mistakes.forEach(m => {
                const item = document.createElement('div');
                item.className = 'result-item';
                item.innerHTML = `
                    <div class="result-item-q">
                        ${m.pronoun.replace('(que) ', '')} <b>(${m.verb})</b>
                        <div class="text-xs text-gray-400">${m.tense}</div>
                    </div>
                    <div class="result-item-a">
                        <span class="user-answer-incorrect">${m.userAnswer || "..."}</span> → 
                        <span class="correct-answer-show">${m.answer}</span>
                    </div>`;
                detailsContainer.appendChild(item);
            });
            containerWrapper.classList.remove('hidden');
            practiceBtn.classList.remove('hidden');
        } else {
            containerWrapper.classList.add('hidden');
            practiceBtn.classList.add('hidden');
        }
    }

    private showResults(): void {
        const { score, questions, isMistakePractice } = this.quizState;
        const total = questions.length;
        const percentage = total > 0 ? (score / total) * 100 : 0;
        this.getEl('final-score').textContent = `${score} / ${total}`;
        
        const nextLevelBtn = this.getEl('next-level-btn');
        const repeatBtn = this.getEl('repeat-level-btn');
        const resultsTitle = this.getEl('results-title');
        const resultsSubtitle = this.getEl('results-subtitle');

        nextLevelBtn.classList.add('hidden');
        repeatBtn.classList.remove('hidden');

        if (isMistakePractice) {
            if (percentage === 100) {
                resultsTitle.textContent = "🎉 ¡Errores Corregidos!";
                resultsSubtitle.textContent = "¡Excelente trabajo, has corregido todos tus errores!";
                this.triggerConfetti();
            } else {
                resultsTitle.textContent = "💪 ¡Casi lo tienes!";
                resultsSubtitle.textContent = "Sigue practicando esos puntos difíciles.";
            }
            repeatBtn.classList.add('hidden');
        } else {
            if (percentage >= 80) {
                resultsTitle.textContent = "🎉 ¡Excelente!";
                resultsSubtitle.textContent = "Dominas este tema. ¡Qué talento!";
                if (this.gameMode === 'progression' && this.currentLevelIndex === this.highestLevelUnlocked) {
                    this.highestLevelUnlocked++;
                }
                if (this.currentLevelIndex < levels.length - 1) {
                    nextLevelBtn.classList.remove('hidden');
                }
                this.triggerConfetti();
            } else if (percentage >= 50) {
                resultsTitle.textContent = "👍 ¡Bien hecho!";
                resultsSubtitle.textContent = "Sigue practicando para mejorar.";
            } else {
                resultsTitle.textContent = "💪 ¡Sigue intentándolo!";
                resultsSubtitle.textContent = "La práctica hace al maestro. ¡No te rindas!";
            }
        }
        this.displayResultsDetails();
        this.showScreen('results-container');
        this.getEl('progress-bar').style.width = '100%';
    }
}

// Instantiate the app to start it
new ConjugadorApp();
